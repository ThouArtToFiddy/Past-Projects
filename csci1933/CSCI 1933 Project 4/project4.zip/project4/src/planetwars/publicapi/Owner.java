package planetwars.publicapi;

public enum Owner {
    SELF,
    OPPONENT,
    NEUTRAL,
}
