package planetwars.core;

enum InternalPlayer {
    PLAYER1,
    PLAYER2,
    NEUTRAL,
}
